You can use this font for personal use only.
We will appreciate your like and your kind donation!

https://paypal.me/humandesign30


For commercial use please purchase at

https://www.creativefabrica.com/designer/human-design

humandesign30@gmail.com